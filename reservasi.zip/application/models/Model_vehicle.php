<?php
/**
 * Created by IntelliJ IDEA.
 * User: DELL
 * Date: 06-Dec-18
 * Time: 9:15 PM
 */

class Model_vehicle extends CI_Model
{
    public function __construct()
    {
        parent::__construct();

        date_default_timezone_set('Asia/Jakarta');
        $this->date_time = date("Y-m-d H:i:s");
        $this->date = date("Y-m-d");
    }

    public function insert($data)
    {
        $this->db->insert('vehicle',$data);
        return $this->db->insert_id();
    }

    public function update($data,$id)
    {
        $this->db->where('vehicle_id',$id);
        $this->db->update('vehicle',$data);
    }

    public function select($id)
    {
        $this->db->select(
            'vehicle_id as id,
            vehicle_type as type,
            vehicle_number as number,
            vehicle_price as price'
        );
        if ( ! is_null($id)) {
            $this->db->where('vehicle_id',$id);
        }
        $this->db->from('vehicle');
        $query = $this->db->get();
        $result = $query->result();
        if (sizeof($result) > 0) return $result;
        else return NULL;
    }

    public function update_feature($data,$id)
    {
        $this->db->where('vehicle_feature_id',$id);
        $this->db->delete('vehicle_feature');

        if (sizeof($data) > 0) {
            $this->db->insert_batch($data);
        }
    }

    public function select_feature($id)
    {
        $this->db->select(
            'vehicle_feature_key as key,
            vehicle_feature_value as value'
        );
        $this->db->where('vehicle_feature_id',$id);
        $this->db->from('vehicle_feature');
        $query = $this->db->get();
        $result = $query->result();
        if (sizeof($result) > 0) return $result;
        else return NULL;
    }
}